module.exports.config = {
    name: "dot",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "RDX_ZAIN",
    description: "War In Chatbox",
    commandCategory: "wargroup",
    usages: "[fyt]",
    cooldowns: 7,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
 var mention = Object.keys(event.mentions)[0];
    
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a(".");
setTimeout(() => {a({body: "." })}, 1000);
setTimeout(() => {a({body: "."})}, 2000);
setTimeout(() => {a({body: "#" })}, 3000);
setTimeout(() => {a({body: "/" })}, 4000);
setTimeout(() => {a({body: "/" })}, 5000);
setTimeout(() => {a({body: "/" })}, 6000);
setTimeout(() => {a({body: "#" })}, 7000);
setTimeout(() => {a({body: "." })}, 8000);
setTimeout(() => {a({body: "." })}, 9000);
setTimeout(() => {a({body: "😘" })}, 10000);
setTimeout(() => {a({body: "." })}, 12000);
setTimeout(() => {a({body: "." })}, 14000);
setTimeout(() => {a({body: "." })}, 16000);
setTimeout(() => {a({body: "." })}, 18000);
setTimeout(() => {a({body: "." })}, 20000);
setTimeout(() => {a({body: "." })}, 22000);
setTimeout(() => {a({body: "." })}, 25000);
setTimeout(() => {a({body: "." })} , 27000);
setTimeout(() => {a({body: "." })} , 30000);
setTimeout(() => {a({body: "." })} , 34000);
setTimeout(() => {a({body: "." })} , 36000);
setTimeout(() => {a({body: "." })} , 38000);
setTimeout(() => {a({body: "." })} , 40000);
setTimeout(() => {a({body: "." })} , 43000);
setTimeout(() => {a({body: "." })} , 46000);
setTimeout(() => {a({body: "." })} , 48000);
setTimeout(() => {a({body: "." })} , 49900);
setTimeout(() => {a({body: "." })} , 50500);
setTimeout(() => {a({body: "." })} , 51000);




  
  }
