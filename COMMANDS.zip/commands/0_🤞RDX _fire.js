const fs = require("fs-extra");

module.exports.config = {
    name: "Fire",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "RDX_ZAIN",
    description: "Fire broke the boxchat",
    commandCategory: "group",
    usages: "bold Fire",
    cooldowns: 10,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

let isOn = false; // Initial state

module.exports.run = async function({ api, args, event }) {
    if (args[0] === "on") {
        isOn = true;
        return api.sendMessage("The Fire command has been turned ON.", event.threadID);
    }
    
    if (args[0] === "off") {
        isOn = false;
        return api.sendMessage("The Fire command has been turned OFF.", event.threadID);
    }

    // If the command is off, exit immediately
    if (!isOn) {
        return api.sendMessage("The Fire command is currently OFF. Use 'Fire on' to turn it on.", event.threadID);
    }

    var mention = Object.keys(event.mentions)[0];
    let name = event.mentions[mention];
    var arraytag = [];
    arraytag.push({ id: mention });
    var a = function (a) { 
        if (isOn) { // Check if the command is still on before sending each message
            api.sendMessage(a, event.threadID); 
        }
    }

    a("T3R9 B99P BOT 3NT3R S9L3 APN3 B99P S3 JUB99N L9D9Y3G9🤞🏻👅👅");
    setTimeout(() => { a({ body: " BOT KO G9LI D3N3 W9LO TUMH9RII B9HN KII (+)🙊💋" }) }, 3000);
    setTimeout(() => { a({ body: " T3RII M99 BHOSD99 F99D KR F3KH DUNG9 S9L33 H9WB99Z T9TT3💋🤣" }) }, 5000);
    setTimeout(() => { a({ body: " T3RII M99 K3 BHOSD33 M3 MOOT DUNG99 M9RCHOXDD😜💔" }) }, 7000);
    setTimeout(() => { a({ body: " T3RII M9 KI (+) R9ND K3 B9XH33🤚🏻💋" }) }, 9000);
    setTimeout(() => { a({ body: " T3RII B9HN KO YHI P979K KR CHOD DUNG99 S9L3😈😍" }) }, 12000);
    setTimeout(() => { a({ body: " T3RI B9HN KI G9ND P3 LOD9 F3KH KR M9RUNG9 S9L3😈👿" }) }, 15000);
    setTimeout(() => { a({ body: " T3RII DIDI KI XHUTT M3 LOD9 D3KR TOD DUNG9 S9L3" }) }, 17000);
    setTimeout(() => { a({ body: " 73RII BH9NN K0 PR36N377 KRUU S9L3💋❤" }) }, 20000);
    setTimeout(() => { a({ body: "T3RII M99 K99 BHOXD99 F99D DUNG99 B9HN K3 LOD33😂💋🤣" }) }, 23000);
    setTimeout(() => { a({ body: " T3RII M99 K99 BHOXD99 F99D DUNG99 B9HN K3 LOD33😋💋" }) }, 25000);
    setTimeout(() => { a({ body: " T3RII BH9N PR3GN37 HO GYII M3R3 L9ND S3 XHUDK3💋❤" }) }, 28500);
    setTimeout(() => { a({ body: "R99ND BN99 DUN699 99J 73RII BH9N K0 S9L3💋❤" }) }, 31000);
    setTimeout(() => { a({ body: "T3RI B9HN K9 BHOSD99 KH99 J99UNG9 S9L3 🙊💋😈" }) }, 36000);
    setTimeout(() => { a({ body: " T3RI DIDI KO 9PN3 KH9D3 LUND PR XHODUNG99 🍷😂🤣" }) }, 39000);
    setTimeout(() => { a({ body: " T3RI DIDI KO 9PN3 KH9D3 LUND PR XHODUNG99💋❤" }) }, 40000);
    setTimeout(() => { a({ body: " T3RII M9 K9 BHOSD99 NOCH LUNG99🤣😂💋" }) }, 65000);
    setTimeout(() => { a({ body: " T3RI B9HN KI XHU7 M3 H99TH D9LKKR USKI B9CHH9D9NNII B9H99R KH33CH LUNG99😂😅" }) }, 70000);
    setTimeout(() => { a({ body: " T3RII L9NGDII M99 KII CHUTT P3 LOD99 F3KH KR M9RU🤣🥳🥳😂" }) }, 75000);
    setTimeout(() => { a({ body: " T3RII M99 K3 MUH M3 F9TT9 C9NDOM LG9 KR LUND D9LUNG9😂😂" }) }, 80000);
    setTimeout(() => { a({ body: " T3RII B9HN K3 BHOSD33 M3 GHUSH J9UNG9 M9DRCHOD😝🤣" }) }, 85000);
    setTimeout(() => { a(" T3RI B9HN KII (+) K99 SIZ3 BT9N99💋😂") }, 90000);
    setTimeout(() => { a({ body: "M9DRCHOD H9W99B9Z T9TT3 COM3DY KR RH9😂😂" }) }, 95000);
    setTimeout(() => { a({ body: "T3RI B9HN KI B9CHH3D9NNNI M3 LUND D3KR USKI B9CH9D9NNI F99D DUNG99💋💋" }) }, 100000);
    setTimeout(() => { a({ body: " T3RII M99 KI S9DII XHUTT PR NIMMBU NICHOD KR RUS NIK9LUNG9💆‍♂️😈❤" }) }, 105000);
    setTimeout(() => { a({ body: " T3RI B9HN KI CHOTI B9DI BOOBS PR LOD99 F3KH KR M9RUNG9 R9NDII K3😈💋" }) }, 115000);
    setTimeout(() => { a({ body: "OK T3R9 B99P J9 RH9 9B RON9 M9T DON 3XII7😈💋" }) }, 120000);
}
