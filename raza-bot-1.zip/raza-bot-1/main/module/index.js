"use strict";

const { login } = require('../src/core/client');

module.exports = { login };
