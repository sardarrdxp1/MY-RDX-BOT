
module.exports = {
    async handle({ api, event, config }) {
        console.log("Attachment:", event);
    }
};
