
module.exports = {
    async handle({ api, event, commands, config }) {
        console.log("Reply event:", event);
    }
};
