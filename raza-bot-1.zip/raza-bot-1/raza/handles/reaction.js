
module.exports = {
    async handle({ api, event, config }) {
        console.log("Reaction:", event);
    }
};
