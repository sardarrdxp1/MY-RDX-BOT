
module.exports = {
    async handle({ api, event, config }) {
        console.log("Read:", event);
    }
};
