
const login = require("../main/module/index");

module.exports = login;
